target = read.table('/ysm-gpfs/pi/gerstein/xk4/TFmembership/edge_allencode.mat.txt',header=T,row.names=1)
expr = read.table("/ysm-gpfs/pi/gerstein/from_louise/skltmp/xm/data/edge_all.exp2quantile.txt",header = TRUE, row.names = 1, sep = "\t")
add_expr = setdiff(colnames(target),colnames(expr))
add_cols = matrix(0,nrow(expr),length(add_expr))
colnames(add_cols) = add_expr
rownames(add_cols) = row.names(expr)
expr = cbind(expr,add_cols)
expr_all = expr[colnames(target)]
expr_all = as.matrix(expr_all)

high_expr = expr_all
high_expr[which(expr_all!=3,arr.ind = TRUE)] = 0
high_expr[which(expr_all==3,arr.ind = TRUE)] = 1
row_sum = apply(high_expr,1,sum)
expr_all=expr_all[which(row_sum>0),]

mid_expr = expr_all
mid_expr[which(expr_all!=2,arr.ind = TRUE)] = 0
mid_expr[which(expr_all==2,arr.ind = TRUE)] = 1
row_sum = apply(mid_expr,1,sum)
expr_all=expr_all[which(row_sum>0),]

low_expr = expr_all
low_expr[which(expr_all!=1,arr.ind = TRUE)] = 0
row_sum = apply(low_expr,1,sum)
expr_all=expr_all[which(row_sum>0),] 

write.table(expr_all,"expr_2quantile_cleaned.csv",sep = "\t")
