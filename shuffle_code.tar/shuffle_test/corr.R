high_data = read.table("high_topics_cor1-10.csv",header = T,row.names = 1,sep = "\t")
mid_data = read.table("mid_topics_cor1-10.csv",header = T,row.names = 1,sep="\t")
low_data = read.table("low_topics_cor1-10.csv",header = T,row.names = 1,sep="\t")

N=10
for (id in seq(2,50)){
	start = (id-1)*N+1
	end = id*N
	data = read.table(paste("high_topics_cor",start,"-",end,".csv",sep=""),sep="\t",header = T,row.names = 1)
	high_data = cbind(high_data,data)

        data = read.table(paste("mid_topics_cor",start,"-",end,".csv",sep=""),sep="\t",header = T,row.names = 1)
        mid_data = cbind(mid_data,data)

        data = read.table(paste("low_topics_cor",start,"-",end,".csv",sep=""),sep="\t",header = T,row.names = 1)
        low_data = cbind(low_data,data)
	}

high_mean = apply(high_data,1,mean)
mid_mean = apply(mid_data,1,mean)
low_mean = apply(low_data,1,mean)

high_sig = apply(high_data,1,sd)
mid_sig = apply(mid_data,1,sd)
low_sig = apply(low_data,1,sd)

write.table(high_mean,"high_mean.csv",sep="\t")
write.table(mid_mean,"mid_mean.csv",sep="\t")
write.table(low_mean,"low_mean.csv",sep = "\t")

write.table(high_sig,"high_sig.csv",sep="\t")
write.table(mid_sig,"mid_sig.csv",sep="\t")
write.table(low_sig,"low_sig.csv",sep = "\t")


