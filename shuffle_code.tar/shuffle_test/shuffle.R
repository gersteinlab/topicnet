args <- commandArgs(TRUE)
N <- as.integer(args[1])
id <- as.integer(args[2])
library(topicmodels)

target = read.table('/ysm-gpfs/pi/gerstein/xk4/TFmembership/edge_allencode.mat.txt',header=T,row.names=1)
expr_all = read.table("/ysm-gpfs/pi/gerstein/xk4/TFmembership/LDA_expr_in_cell/shuffle_test/expr_2quantile_cleaned.csv",header = TRUE, row.names = 1, sep = "\t")
topics = read.table("/ysm-gpfs/pi/gerstein/xk4/TFmembership/LDAmodels/50_topics.txt",header = T)
row.names(topics) <- row.names(target)
topics = topics[row.names(expr_all),]
topics = as.matrix(topics)

load("/ysm-gpfs/pi/gerstein/xk4/TFmembership/LDAmodels/50_model.rdata")

l = length(expr_all[,1])
high_topics_cor = matrix(0,l,N)
mid_topics_cor = matrix(0,l,N)
low_topics_cor = matrix(0,l,N)

for (i in 1:N){
	cat(i,"\r")
	shuffle<-t(apply(expr_all, 1, function(x){
		x=as.numeric(x);
		xx.tt=x[which(x>0)]
		x[which(x>0)] = sample(xx.tt)
		x
	}))
	colnames(shuffle) = colnames(expr_all)	
	high_expr = shuffle
	high_expr[which(shuffle!=3,arr.ind = TRUE)] = 0
	high_expr[which(shuffle==3,arr.ind = TRUE)] = 1
	high = posterior(model,high_expr)
	high_topics = high$topics
	high_topics_cor[,i] = sapply(1:l, function(x) cor(topics[x,], high_topics[x,]))
	
	mid_expr = shuffle
	mid_expr[which(shuffle!=2,arr.ind = TRUE)] = 0
	mid_expr[which(shuffle==2,arr.ind = TRUE)] = 1
        mid = posterior(model,mid_expr)
        mid_topics = mid$topics
        mid_topics_cor[,i] = sapply(1:l, function(x) cor(topics[x,], mid_topics[x,]))

	low_expr = shuffle
	low_expr[which(shuffle!=1,arr.ind = TRUE)] = 0
        low = posterior(model,low_expr)
        low_topics = low$topics
        low_topics_cor[,i] = sapply(1:l, function(x) cor(topics[x,], low_topics[x,]))

	k = (id-1)*N+i	
	write.table(shuffle, file=paste("shuffle_", k,".txt",sep=""), sep="\t", quote=F, row.names=T, col.names=T)
	}  

start = (id-1)*N+1
end = id*N
write.table(high_topics_cor,paste("high_topics_cor",start,"-",end,".csv",sep=""),sep="\t")
write.table(mid_topics_cor,paste("mid_topics_cor",start,"-",end,".csv",sep=""),sep="\t")
write.table(low_topics_cor,paste("low_topics_cor",start,"-",end,".csv",sep=""),sep="\t")
